import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;

public class MyCalculator implements ActionListener{
	
	JFrame frame;
	JTextField textField;
	JButton[] numberButtons = new JButton[10];
	JButton[] functionButtons = new JButton[13];
	JButton addButton, subButton, mulButton, divButton, decimalButton, equButton, delButton, clrButton;
	JButton modButton, negButton, cubicButton, squareButton, sqrtButton;
	JPanel topPanel;
	JPanel centralPanel;
	JPanel bottomPanel;
	
	Font textFont = new Font("TimeRoman", Font.BOLD, 75);
	Font buttonFont = new Font("TimeRoman", Font.BOLD, 35);
	
	//initial operands
	double operand1 = 0, operand2 = 0, result = 0;
	char operator;
	
	public MyCalculator()
	{
		frame = new JFrame();
		frame.setTitle("MyCalculator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(420, 550);
		frame.setLocation(500,200);
		frame.setLayout(new BorderLayout());
		
		//declare text field
		textField = new JTextField(6);
		textField.setFont(textFont);
		textField.setBackground(Color.WHITE);
		textField.setEditable(false);
		
		//declare function buttons
		addButton = new JButton("+");
		subButton = new JButton("-");
		mulButton = new JButton("*");
		divButton = new JButton("/");
		decimalButton = new JButton(".");
		equButton = new JButton("=");
		delButton = new JButton("DEL");
		clrButton = new JButton("C");
		modButton = new JButton("%"); 
		negButton = new JButton("(-)");
		cubicButton = new JButton("x^3");
		squareButton = new JButton("x^2");
		sqrtButton = new JButton("sqrt");
		
		functionButtons[0] = addButton;
		functionButtons[1] = subButton;
		functionButtons[2] = mulButton;
		functionButtons[3] = divButton;
		functionButtons[4] = decimalButton;
		functionButtons[5] = equButton;
		functionButtons[6] = delButton;
		functionButtons[7] = clrButton;
		functionButtons[8] = modButton;
		functionButtons[9] = negButton;
		functionButtons[10] = cubicButton;
		functionButtons[11] = squareButton;
		functionButtons[12] = sqrtButton;
		
		//configure function buttons
		for(int i = 0; i < functionButtons.length; i++)
		{
			functionButtons[i].addActionListener(this);
			functionButtons[i].setFont(buttonFont);
			functionButtons[i].setFocusable(false);
		}
		
		//declare and configure numberButtons
		for(int i = 0; i < numberButtons.length; i++)
		{
			numberButtons[i] = new JButton("" + i);
			numberButtons[i].addActionListener(this);
			numberButtons[i].setFont(buttonFont);
			numberButtons[i].setFocusable(false);
		}
		
		//configure top panel
		topPanel = new JPanel(new FlowLayout());
		topPanel.add(textField);
		
		//configure central panel
		centralPanel = new JPanel();
		centralPanel.setLayout(new GridLayout(5,4,0,0));
		
		//central panel row 1
		centralPanel.add(functionButtons[10]);
		centralPanel.add(functionButtons[11]);
		centralPanel.add(functionButtons[12]);
		centralPanel.add(functionButtons[3]);
		
		//central panel row 2
		centralPanel.add(numberButtons[7]);
		centralPanel.add(numberButtons[8]);
		centralPanel.add(numberButtons[9]);
		centralPanel.add(functionButtons[2]);
		
		//central panel row 3
		centralPanel.add(numberButtons[4]);
		centralPanel.add(numberButtons[5]);
		centralPanel.add(numberButtons[6]);
		centralPanel.add(functionButtons[1]);
		
		//central panel row 4
		centralPanel.add(numberButtons[1]);
		centralPanel.add(numberButtons[2]);
		centralPanel.add(numberButtons[3]);
		centralPanel.add(functionButtons[0]);

		//central panel row 5
		centralPanel.add(functionButtons[9]);
		centralPanel.add(numberButtons[0]);
		centralPanel.add(functionButtons[4]);
		centralPanel.add(functionButtons[8]);

		//configure bottom panel
		bottomPanel = new JPanel(new GridLayout());
		bottomPanel.add(functionButtons[7]);
		bottomPanel.add(functionButtons[6]);
		bottomPanel.add(functionButtons[5]);
		
		//add panels to frame
		frame.add(topPanel, BorderLayout.NORTH);
		frame.add(centralPanel, BorderLayout.CENTER);
		frame.add(bottomPanel, BorderLayout.SOUTH);
		frame.setVisible(true);
		
	}
	
	//driver
	public static void main(String[] arg)
	{
		MyCalculator cal = new MyCalculator();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//read input number buttons and display it in text area
		for(int i = 0; i < 10; i++)
		{
			if(e.getSource() == numberButtons[i])
			{
				textField.setText(textField.getText().concat(String.valueOf(i)));
			}
		}
		
		//actions on function buttons
		if(e.getSource() == decimalButton)
		{
			textField.setText(textField.getText().concat("."));
		}
		
		else if(e.getSource() == addButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			operator = '+';
			textField.setText("");
		}
		
		else if(e.getSource() == subButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			operator = '-';
			textField.setText("");
		}
		
		else if(e.getSource() == mulButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			operator = '*';
			textField.setText("");
		}
		
		else if(e.getSource() == divButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			operator = '/';
			textField.setText("");
		}
		
		else if(e.getSource() == modButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			operator = '%';
			textField.setText("");
		}
		
		else if(e.getSource() == cubicButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			result = (operand1 * operand1) * operand1;
			textField.setText(String.valueOf(result));
		}
		
		else if(e.getSource() == squareButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			result = operand1 * operand1;
			textField.setText(String.valueOf(result));
		}
		
		else if(e.getSource() == sqrtButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			result = Math.sqrt(operand1);
			textField.setText(String.valueOf(result));
		}
		
		else if(e.getSource() == equButton)
		{
			operand2 = Double.parseDouble(textField.getText());
			
			switch(operator)
			{
			case'+':
				result = operand1 + operand2;
				break;
				
			case'-':
				result = operand1 - operand2;
				break;
				
			case'*':
				result = operand1 * operand2;
				break;
				
			case'/':
				result = operand1 / operand2;
				break;
				
			case'%':
				result = operand1 % operand2;
				break;
			}
			
			textField.setText(String.valueOf(result));
			operand1 = result;
		}
		
		else if(e.getSource() == negButton)
		{
			operand1 = Double.parseDouble(textField.getText());
			result = operand1 * -1;
			textField.setText(String.valueOf(result));
		}
		
		else if(e.getSource() == clrButton)
		{
			textField.setText("");
		}
		
		else if(e.getSource() == delButton)
		{
			String string = textField.getText();
			//delete the current string
			textField.setText("");
			//re-print the string with the last char removed
			for(int i = 0; i < string.length()-1; i++)
			{
				textField.setText(textField.getText()+string.charAt(i));
			}
		}
		

	}

}
